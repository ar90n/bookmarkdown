# Icons

This directory should contain the following icon files for the Chrome extension:

- icon16.png - 16x16 pixel icon
- icon32.png - 32x32 pixel icon  
- icon48.png - 48x48 pixel icon
- icon128.png - 128x128 pixel icon

Create these icons with the BookMarkDown branding (book/bookmark theme).

For development, you can use placeholder icons or create simple ones using any image editor.