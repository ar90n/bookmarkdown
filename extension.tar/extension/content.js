// BookMarkDown - Content Script
// This script bridges the web app and the Chrome extension

console.log('📱 BookMarkDown Content Script loaded');
console.log('🌐 Current URL:', window.location.href);
console.log('🆔 Extension ID:', chrome.runtime.id);

// Wait for DOM to be ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectExtensionInfo);
} else {
  injectExtensionInfo();
}

function injectExtensionInfo() {
  console.log('💉 Injecting extension info into page...');
  
  try {
    // Method 1: DOM attributes (works across contexts)
    document.documentElement.setAttribute('data-bookmarkdown-extension-id', chrome.runtime.id);
    document.documentElement.setAttribute('data-bookmarkdown-available', 'true');
    console.log('🔗 DOM attributes set:', chrome.runtime.id);
    
    // Method 2: PostMessage to web app (works across contexts)
    window.postMessage({
      type: 'BOOKMARKDOWN_EXTENSION_READY',
      extensionId: chrome.runtime.id,
      available: true,
      source: 'bookmarkdown-content-script'
    }, '*');
    console.log('📡 PostMessage sent to web app');
    
    // Method 3: Try direct window assignment (may not work due to context)
    try {
      window.bookmarkdownExtensionAvailable = true;
      window.bookmarkdownExtensionId = chrome.runtime.id;
      console.log('🌐 Direct window assignment attempted');
    } catch (windowError) {
      console.log('⚠️ Direct window assignment failed (expected in some contexts)');
    }
    
    // Method 4: Try script injection as fallback
    try {
      const script = document.createElement('script');
      script.textContent = `
        window.bookmarkdownExtensionAvailable = true;
        window.bookmarkdownExtensionId = '${chrome.runtime.id}';
        console.log('🌐 BookMarkDown extension availability injected via script');
      `;
      (document.head || document.documentElement).appendChild(script);
      script.remove();
      console.log('✅ Script injection completed');
    } catch (scriptError) {
      console.log('⚠️ Script injection failed:', scriptError.message);
    }
    
  } catch (error) {
    console.error('❌ Error injecting extension info:', error);
  }
  
  console.log('✅ Extension info injection completed');
}

// Listen for messages from the web app
window.addEventListener('message', async (event) => {
  if (event.source !== window) return;
  
  if (event.data.type === 'BOOKMARKDOWN_GET_TABS') {
    console.log('📥 Received request for tabs from web app');
    
    try {
      // Get tabs from chrome.storage.local via background script
      const response = await chrome.runtime.sendMessage({
        action: 'getAllTabs'
      });
      
      console.log('📤 Sending tabs to web app:', response.allTabsInfo);
      
      // Send response back to web app
      window.postMessage({
        type: 'BOOKMARKDOWN_TABS_RESPONSE',
        tabs: response.allTabsInfo || []
      }, '*');
    } catch (error) {
      console.error('❌ Error getting tabs:', error);
      window.postMessage({
        type: 'BOOKMARKDOWN_TABS_ERROR',
        error: error.message
      }, '*');
    }
  }
});

console.log('✅ BookMarkDown Content Script initialized');